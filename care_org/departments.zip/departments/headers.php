<!--- 
Global Header File for all the Scripts
Do not delete
Custom styles can be implemented in the Independent scripts
-->
    <!--Open Sans Font [ OPTIONAL ]-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>

    <!--Bootstrap Stylesheet [ REQUIRED ]-->
    <link href="..\css\bootstrap.min.css" rel="stylesheet">

    <!--Nifty Stylesheet [ REQUIRED ]-->
    <link href="..\css\nifty.min.css" rel="stylesheet">

    <!--Nifty Premium Icon [ DEMONSTRATION ]-->
    <link href="..\css\demo\nifty-demo-icons.min.css" rel="stylesheet">

    <link href="..\plugins\ionicons\css\ionicons.min.css" rel="stylesheet">

    <link href="..\plugins\font-awesome\css\font-awesome.min.css" rel="stylesheet">

    <!--Pace - Page Load Progress Par [OPTIONAL]-->
    <link href="..\plugins\pace\pace.min.css" rel="stylesheet">
    <script src="..\plugins\pace\pace.min.js"></script>

    <!--DataTables [ OPTIONAL ]-->
    <link href="..\plugins\datatables\media\css\dataTables.bootstrap.css" rel="stylesheet">
	<link href="..\plugins\datatables\extensions\Responsive\css\responsive.dataTables.min.css" rel="stylesheet">